<?php
//if(!empty($_post[submit']){
	//$total=$_post['total'];
	
require("fpdf/fpdf.php");

$pdf=new fpdf();
$pdf->AddPage();
$pdf->Image('ss.jpg');
$pdf->SetFont("Arial","B","16");
$pdf->Cell(0,10,"ShopIt",1,1,"C");
$pdf->output();
//}
?>