<html>
    <head>
        <title>bill</title>
    <h1><center>"ShopIt.com"</center></h1>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            #bill
            {
                
            }
        </style>
    </head>
    <body background="f98.jpg">
        <div id="bill">
    <form name="f1" method="post" action="buy.php" id="f1">
        <center>
        <table>
            <caption><b>Bill</b></caption>
            <tr>
                <td class="f1_label">Quantity:</td>
                <td><input type="text" name="p" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Price:</td>
                <td><input type="label" name="p" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Total:</td>
                <td><input type="label" name="p" value="" /> </td>
            </tr>
   
        </table>
            </center>
    </form> 
</div>
       <h1><center>Thank you For buying...!!<br>visit again..</center></h1>
    </body>
</html>
