<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            .div2{
                margin-top: 0px;
            }
        </style>
    </head>
    <a href="amanger.php"><input type="button" name="display"  value="back" style="left: 15px; top: 0px;"/></a>

    <h1><b>ONLINE LAPTOP SHOPPING</b></h1>
    <h1><b>Available Laptop</b></h1>
  <link rel="stylesheet" type="text/css" href="home.css">
<body background="p9.jpg">
     </div>
     
    <div class="div2">
        <marquee>
        <img src="c1.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c2.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c3.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c4.jpg" alt="" style="width:350px;height:350px;">
        <img src="c5.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c6.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c7.jpeg" alt="" style="width:350px;height:350px;">
        </marquee>
    </div>

    


<?php
include "database.php";


echo"<center>";
echo"<table border=2 bgcolor=#f2f2f2>"."<tr>";
echo"<th>"."lap_id"."</th>";
echo"<th>"."quantity"."</th>";
echo"<th>"."color"."</th>";
echo"<th>"."Price"."</th></tr>";

$sql1="select * from laptop";
$result1 = $conn->query($sql1); 

          // $result1=$coll1->find();
        foreach($result1 as $doc)
        {
      echo"<tr><td>".$doc['lap_id']."</td>"."<td>".$doc['quantity']."</td>"."<td>".$doc['color']."</td>"."<td>".$doc['price']."</td>"."</tr></>";

        }

echo"</table>";
echo"</center>";

?>


        

   
   



    
</body>
</html>
