
PrinterJob job = PrinterJob.getPrinterJob();
            job.setJobName("Print Data");
            
            job.setPrintable(new Printable(){
            public int print(Graphics pg,PageFormat pf, int pageNum){
                    pf.setOrientation(PageFormat.LANDSCAPE);
                 if(pageNum>0){
                    return Printable.NO_SUCH_PAGE;
                }
                
                Graphics2D g2 = (Graphics2D)pg;
                g2.translate(pf.getImageableX(), pf.getImageableY());
                g2.scale(0.24,0.24);
                
                jPanel1.paint(g2);
//          
               
                return Printable.PAGE_EXISTS;
                         
                
            }

   
    });
        
            
               boolean ok = job.printDialog();
        if(ok){
        try{
            
        job.print();
        this.setVisible(false);
        Thanku t=new Thanku();
        t.setVisible(true);
        }
        catch (PrinterException ex){}
        
 
    }

        // TODO add your handling code here:
