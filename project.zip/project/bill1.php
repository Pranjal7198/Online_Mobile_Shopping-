<?php
session_start();
$_SESSION['id']=$_POST['p'];
$_SESSION['quantity']=$_POST['quan'];

$cprice="select price from available where computer_id=id";

