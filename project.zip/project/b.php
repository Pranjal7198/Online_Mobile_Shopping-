
<html>
    <head>
        <style>
           
            #f1 {
    background-color: #ccc;
    border-radius: 5px;
    border-style: solid;
    border-width: 1px;
    padding: 10px;
    height: 200px;
    width: 300px;
    margin-left: 600px;
    margin-top: 75px;
            }
            #bill {
    position: absolute;
    top: 10%;
    left: -5%;
    right: 100%;
    bottom: 20%;
    font-size: 18px;
}
 
        </style>
    </head>
<body background="f98.jpg">
       <?php session_start();
       //$a=$_POST['quan'];
	    include 'database1.php';
    if(isset($_POST)  && !empty($_POST['p']))
    {
       $a=$_SESSION['quantity'];
       $price=$_POST['price'];
       $c=$a*$price;
	   $dbObj=new Db();
    $con=$dbObj->Connect();
	   $result = mysql_query("select price from available where computer_id='$p'");
	    $result=mysqli_query($con,$sql);
    if(mysqli_num_rows($result) > 0)
    {
    while($rows=mysqli_fetch_assoc($result))
    {
    header('Location:buy.php');
    }
    }
    else
    {
    echo ' wrong';
    }
    mysqli_close($con);  
    }

	   ?>
	   
	   
        <div id="bill">
    <form name="f1" method="post" action="" id="f1">
        <center>
        <table>
            <caption><b>Bill</b></caption>
            <tr>
                <td class="f1_label">Quantity:</td>
                <td><input type="text" name="quan" value="<?php echo $a ?>"  disabled/> </td>
            </tr>
            <tr>
                <td class="f1_label">Price:</td>
                <td><input type="text" name="price" value="<?php echo $_SESSION['price']?>"  disabled/> </td>
            </tr>
            <tr>
               
                <td class="f1_label">Total:</td>
                <td><input type="label" name="p3" value="<?php echo $c; ?>" disabled /> </td>
            </tr>
            <tr>
                <td> <input type="submit" name="Submit" value="home" formaction="home.html" style="font-size:18px; " /></td>
                
            </tr>
   
        </table>
            </center>
    </form> 
</div>
</body>
</html>
       