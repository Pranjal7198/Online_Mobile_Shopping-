
    <html>
    <head>
        <title>specification</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            .div1
            {
                font-size:20px;
                margin-left:500px;
                margin-top: 0px;
            }
            .img
            {
               height: 600px;
               width: 450px;
               float:left;
                
            }
        </style>
    </head>
    <body background="a1.jpg">
        <div class="img">
        <img src="2.jpg" alt="" style="width:400px;height:400px;">
        </div>
        <div class="div1">
        <ul>
        <b>Features</b><br>
        <li>computer id :104</li>
        <li>Intel Core i5 (5th Gen) Processor</li>
        <li>8 GB DDR3 RAM</li>
        <li>64 bit Windows 10 Operating System</li>
        <li>1 TB HDD</li>
        <li>15.6 inch Display</li> 
        <li>price:30000</li>
        </ul>
        </div>
        <a href="index.php?id=104"><input type="button" name="display"  value="Buy" style="left:500px; top: 100px;"/></a>
    </body>
    </html>

