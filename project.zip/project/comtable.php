<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <style>
    #comdetails_form {
    position: absolute;
    top: 20%;
    left: 30%;
    right: 30%;
    bottom: 20%;
    font-size: 18px;
}

#f1 {
    background-color: #ccc;
    border-radius: 5px;
    border-style: solid;
    border-width: 1px;
    padding: 10px;
    height: 100px;
    width: 300px;
    margin-left: 300px;
    margin-top: 270px
 
  
  
}
.div2{
    margin-top:50px;
}
.f1_label {
   
   
}
.body{
    background-color:#d9f2e6;
}
        </style>

    </head>
    <h1><b>ONLINE COMPUTER SHOPPING</h1>
    <h1><b>Available computers</h1>
  <link rel="stylesheet" type="text/css" href="home.css">
<body background="p9.jpg">
    
    <div class="div2">
        <marquee>
        <img src="c1.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c2.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c3.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c4.jpg" alt="" style="width:350px;height:350px;">
        <img src="c5.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c6.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c7.jpeg" alt="" style="width:350px;height:350px;">
        </marquee>
    </div>

    


<?php

$m=new mongo();
$db=$m->pd;
$coll1=$db->computer;

echo"<center>";
echo"<table border=2 bgcolor=#f2f2f2>"."<tr>";
echo"<th>"."computer_id"."</th>";
echo"<th>"." Name"."</th>";
echo"<th>"."Company"."</th>";
echo"<th>"."Model"."</th>";
echo"<th>"."color"."</th>";
echo"<th>"."quantity"."</th>";
echo"<th>"."Price"."</th></tr>";

         $result1=$coll1->find();
        foreach($result1 as $doc)
        {
      echo"<tr><td>".$doc['computer_id']."</td>"."<td>".$doc['name']."</td>"."<td>".$doc['company']."</td>"."<td>".$doc['model']."</td>"."<td>".$doc['color']."</td>"."<td>".$doc['quantity']."</td>"."<td>".$doc['price']."</td>"."</tr></>";

        }

echo"</table>";
echo"</center>";

?>
<div id="comdetails_form">
    <form name="f1" method="post" action="buy.php" id="f1">
        <table>
            <caption><b>Enter computer id to be buy</b></caption>
            <tr>
                <td class="f1_label">Computer id :</td>
                <td><input type="text" name="p" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Quantity :</td>
                <td><input type="text" name="quan" value="" /> </td>
            </tr>
            
            
            <tr>
                <td>
                    <input type="submit" name="Submit" value="submit" style="font-size:18px; " /></td>
                   <td> <a href="home.html"><input type="button" name="display" value="back" style="font-size:18px;"  /></a>

                </td>
                    
            </tr>
            
             
        </table>
    </form> 
</div>




    
</body>
</html>
