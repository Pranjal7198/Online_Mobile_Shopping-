<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>computer details form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
    #comdetails_form {
    position: absolute;
    top: 20%;
    left: 30%;
    right: 30%;
    bottom: 20%;
    font-size: 18px;
}

#f1 {
    background-color: #ccc;
    border-radius: 5px;
    border-style: solid;
    border-width: 1px;
    padding: 10px;
    height: 275px;
    width: 300px;
    margin-left: 200px;
    margin-top: 100px
 
  
  
}
.div2 {
    margin-top: 70px;
   
   
}
.body{
    background-color:#d9f2e6;
}
        </style>
    </head>
        
    
    <a href="amanger.php"><input type="button" name="display"  value="back" style="left: 15px; top: 0px;"/></a>

    <body>
        <h1>ONLINE COMPUTER SHOPPING</h1>
        <h2>Computer detail form</h2>
  <link rel="stylesheet" type="text/css" href="home.css">
  <body background="p9.jpg">

   
      

    <div id="comdetails_form">
    <form name="f1" method="post" action="com_detail.php" id="f1">
        <table>
            <tr>
                <td class="f1_label">Computer id :</td>
                <td><input type="text" name="id" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">name :</td>
                <td><input type="text" name="n" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Company :</td>
                <td><input type="text" name="c" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Model :</td>
                <td><input type="text" name="m" value="" /> </td>
            </tr>
            
            <tr>
                <td class="f1_label">Color :</td>
                <td><input type="text" name="color" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">quantity :</td>
                <td><input type="text" name="q" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">price :</td>
                <td><input type="text" name="p" value="" /> </td>
            </tr>
   
            <tr>
                <td>
                    <input type="submit" name="Submit" value="INSERT" onclick="validate()" style="font-size:16px " />
                </td>
                    <td>
                    <a href="comdisp.php"><input type="button" name="display" value="DISPLAY" style="font-size:16px; "  /></a>
                </td>
            </tr>
             <tr>
                <td>
                    <a href="comdelete.php"><input type="button" name="display" value="DELETE" style="font-size:16px; "  /></a>
                </td>
                    <td>
                    <a href="comup.php"><input type="button" name="display" value="UPDATE" style="font-size:16px; " /></a>
                    <a href="home.html"><input type="button" name="back" value="home" style="font-size:16px; "/></a>
                </td>
            </tr>
                        
        </table>
    </form> 
</div>
      <script>
        function validate()
        {
            var i;
            var ele, flag = 0;
            ele = document.getElementsByTagName("INPUT");
            for (i = 0; i < ele.length; i++)
            {
                if (ele[i].value == "")
                {
                    alert(" plz fill in all entries");
                    flag = 1;
                    break;
                }

            }

            
            if (flag == 0)
            {
                alert(" Thank You!!!");

            }




        }

    </script>
  </body>
   
</html>