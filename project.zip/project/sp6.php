
    <html>
    <head>
        <title>specification</title>
        <meta charset="UTF-8">
        <meta name="viewport" content=a"width=device-width, initial-scale=1.0">
        <style>
            .div1
            {
                font-size:20px;
                margin-left:500px;
                margin-top: 0px;
            }
            .img
            {
               height: 600px;
               width: 450px;
               float:left;
                
            }
        </style>
    </head>
    <body background="a1.jpg">
        <div class="img">
        <img src="3.png" alt="" style="width:400px;height:400px;">
        </div>
        <div class="div1">
        <ul>
        <b>Features</b><br>
        <li>computer id :105</li>
           <li> Intel Core i3 (5th Gen) Processor</li>
           <li> 4 GB DDR3 RAM</li>
<li>Free DOS Operating System</li>
<li>1 TB HDD</li>
<li>15.6 inch Display</li>
<li> Number:15-be005TU</li>
<li>Part Number:X5Q17PA</li>
<li>Model Name:Imprint</li>
<li>Series:Imprint</li>
<li>price:35000RS</li>
        </ul>
        </div>
        <a href="p.php?id=105"><input type="button" name="display"  value="Buy" style="left:500px; top: 100px;"/></a>
    </body>
    </html>

