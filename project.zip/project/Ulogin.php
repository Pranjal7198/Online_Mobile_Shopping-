
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->	
<?php
	// ob_start();
	session_start();

	include "database.php";
	if(isset($_POST)  && !empty($_POST['u']) && !empty($_POST['p']))
	{
	$username=$_POST['u'];
	$password=$_POST['p'];
	
	$q="select * from `user` where  `user`='".$username."' and  `pass`='".$password."'";
	$res=$conn->query($q);
	if(mysqli_num_rows($res)>0)
	{
	  
		echo "<script>window.location='detail.html';</script>";
	}
	else
	{
		$message="Incorrect username/password found!";
		echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script>window.location='Ulogin.php';</script>";
		echo"<script>close()</script>";
	}
	}

?>

<html>
    <a href="home.htm"><input type="button" name="display"  value="back" style="left: 15px; top: 0px;"/></a>

    <head>
        <title>login form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
    #login_form {
    position: absolute;
    top: 25%;
    left: 25%;
    right: 30%;
    bottom: 20%;
    font-size: 18px;
}

     .div2{
                margin-top: 100px;
            }
        

#f1 {
   
   
    padding: 10px;
    height: 150px;
    width: 300px;
    margin-left: 200px;
    margin-top: 100px
  
  
}
.f1_label {
   
   
}
/*.body{
    background-color:#d9f2e6;
}*/
        </style>
    </head>
        
    
    
    
        <h1><center style="color:orange">USER Login</h1>
  <link rel="stylesheet" type="text/css" href="home.css">
  <body background="home.jpg">

   

        <div id="login_form">
    <form name="f1" method="post" action="" id="f1">
        <table>
            <tr>
                <td class="f1_label"><b>User Name :</b></td><br><br>
                <td><input type="text" name="u" value="" /> </td>
            </tr>
            <tr>
               <td class="f1_label"><b>Password  :</b></td>
                <td><input type="password" name="p" value=""  /></td>
            </tr>
            <tr>
                <td>
                    <input type="submit" name="login" value="Log In" style="font-size:18px; " />
                </td>
            </tr>
        </table>
    </form> 
</div>
  </body>
   
</html>