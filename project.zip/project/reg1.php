<?php  
    include "database.php";
?>

<?php
   
    $fname = $_POST['f1'];
	$lname = $_POST['l1'];
	$email = $_POST['email'];
	$user =  $_POST['user'];
	$key = $_POST['pass'];
	$address = $_POST['ad'];
	$mobile = $_POST['mn'];
	
	
	$sql = "insert into user values('$fname','$lname','$email','$user','$key','$mobile','$address')";
    
	$result = $conn->query($sql);
	      if($result===TRUE)
		  {
			  echo "<script type='text/javascript'>alert('Thank you');</script>";
		      echo "<script>window.location='reg.php';</script>";
		  }
		  else
		  { echo "<script type='text/javascript'>alert('Username Already exist');</script>";
		     echo "<script>window.location='reg.php';</script>";
		  }
	$conn->close();
		  ?>