


<html>
    <head>
        <title>registration form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body background="a3.jpg">
        <a href="spici.php">
            <img src="hpi3.jpg" alt="" style="width:330px;height:325px;">
        </a>
        <a href="speci4.php">
            <img src="len.jpg" alt="" style="width:330px;height:325px;">
        </a>
        <a href="speci3.php">
            <img src="Asus.jpg" alt="" style="width:330px;height:325px;">
        </a>
        <a href="speci2.php">
            <img src="linovai3.jpg" alt="" style="width:330px;height:325px;">
        </a>
        <a href="speci1.php">
            <img src="a2.jpg" alt="" style="width:330px;height:325px;">
        </a>
        <a href="speci5.php">
            <img src="hp1.jpg" alt="" style="width:330px;height:325px;">
        </a>
        <a href="speci4.php">
            <img src="c4.jpg" alt="" style="width:330px;height:325px;">
        </a>
        <a href="speci4.php">
            <img src="c5.jpeg" alt="" style="width:330px;height:325px;">
        </a>
    </body>
    </body>

<?php
?>
</html>