<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <a href="home.htm"><input type="button" name="display"  value="back" style="left: 15px; top: 0px;"/></a>

    <head>
        <title>registration form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
    #Reg_form {
    position: absolute;
   
    top: 5%;
    left: 20%;
    right: 50%;
    bottom: 20%;
    font-size: 18px;
}

#f1 {
    background-color: #ccc;
    border-radius: 5px;
    border-style: solid;
    border-width: 1px;
    padding: 10px;
    height: 300px;
    width: 300px;
    margin-left: 600px;
    margin-top: 75px
 
  
  
}
 span
        {
            color:red;

        }

.f1_label {
   
   
}
.body{
    background-color:yellow;
}
        </style>
    </head>
  

              <body>
    
    
    
        
        <h3><center>User Registration form</h3>
  <link rel="stylesheet" type="text/css" href="home.css">
  <body background="o.jpg">

    
      
        <div id="login_form">
    <form name="f1" method="POST" action="reg1.php" id="f1">
        <table>
            
            <tr>
                <td class="f1_label"><b>First Name :</b></td>
                <td><input type="text" name="f1" /> 
       
               <span style="color:red"> * </span><br><br>
                </td>
            
            </tr>
            <tr>
                <td class="f1_label"><b>Last Name :</b></td>
                <td><input type="text" name="l1"/>
              
                </td>
                 
            </tr>
            <tr>
                <td class="f1_label"><b>Email :</b></td>
                <td><input type="email" name="email" /> 
                 
                 </td>
            </tr>
            <tr>
                <td class="f1_label"><b>User Name :</b></td>
                <td><input type="text" name="user" > 
                
                 </td>
            </tr>
            <tr>
               <td class="f1_label"><b>Password  :</b></td>
                <td><input type="password" name="pass" /></td>
            </tr>
            <tr>
                <td class="f1_label"><b>Address :</b></td>
                <td><textarea rows="3" cols="15" name="ad"></textarea> </td>
            </tr>
            <tr>
                <td class="f1_label"><b>Mobile No :</b></td>
                <td><input type="text" name="mn" value="" id="mobnum"/> 
             
                 </td>
            </tr>
            <tr>
                <td>       </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" name="submit" value="submit" onclick="validate()" style="font-size:18px; " />
                </td>
                
            </tr>
            
        </table> 
    </form> 
                
            
        </div>
       <script>
        function validate()
        {
            var i;
            var ele, flag = 0;
            ele = document.getElementsByTagName("INPUT");
            for (i = 0; i < ele.length; i++)
            {
                if (ele[i].value == "")
                {
                    alert(" plz fill in all entries");
                    break;
                }

            }
        }

    </script>
    
  </body>
</html>
    


    
        