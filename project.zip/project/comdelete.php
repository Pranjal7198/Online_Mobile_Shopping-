<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>computer details form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
    #comdetails_form {
    position: absolute;
    top: 20%;
    left: 30%;
    right: 30%;
    bottom: 20%;
    font-size: 18px;
}

#f1 {
    background-color: #ccc;
    border-radius: 5px;
    border-style: solid;
    border-width: 1px;
    padding: 10px;
    height: 100px;
    width: 300px;
    margin-left: 200px;
    margin-top: 150px
 
  
  
}
.div2 {
   margin-top: 100px;
   
}
.body{
    background-color:#d9f2e6;
}
        </style>
    </head>
        
    
    
    <body>
        <h1>ONLINE COMPUTER SHOPPING</h1>
  <link rel="stylesheet" type="text/css" href="home.css">
  <body background="p9.jpg">

    <div class="div2">
        <marquee>
        <img src="c1.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c2.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c3.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c4.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c5.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c6.jpeg" alt="" style="width:350px;height:350px;">
        <img src="c7.jpeg" alt="" style="width:350px;height:350px;">
        </marquee>
    </div>

    <div id="comdetails_form">
        <form name="f1" method="post" action="comdelete1.php" id="f1">
        <table>
            <caption><b>Enter computer id to be deleted</b></caption>
            <tr>
                <td class="f1_label">Computer id :</td>
                <td><input type="text" name="id" value="" /> </td>
            </tr>
            
            <tr>
                <td>
                    <input type="submit" name="Submit" value="submit" style="font-size:18px; " /></td>
                   <td> <a href="amanger.php"><input type="button" name="display" value="back" style="font-size:18px;"  /></a>

                </td>
                    
            </tr>
            
             
        </table>
    </form> 
</div>
   
</html>