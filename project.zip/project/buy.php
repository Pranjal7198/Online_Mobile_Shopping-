<?php  
    include "database.php";
	
?>
<?php
session_start();
$id=$_POST['p'];
$quant=$_POST['quan'];


$sql="update available set quantity=quantity-'$quant' where computer_id='$id' ";
$result = $conn->query($sql);
 $sq="select price from available where computer_id='$id' ";
		  $result1 = $conn->query($sq); 
		if(1){
		while($row=$result1->fetch_assoc()){
			//echo "laptop price:  ".$row["price"];
			 $total=$row["price"]*$quant;
		}
		}
	  
		  ?>  
		  
		  
		  <html>
    <head>
        <title>bill</title>
    <h1><center>"ShopIt.com"</center></h1>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            #bill
            {
                
            }
        </style>
    </head>
    <body style="background:linear-gradient(to left, red,yellow);">
        <div id="bill">
    <form name="f1" method="post" action="print.php" id="f1">
        <center>
        <table>
            <caption><b>Bill</b></caption>
            <tr>
			<?php
                echo"<td class='f1_label'>Quantity:&nbsp $quant</td>";
            ?>    
            </tr>
            <tr>
            </tr>
            <tr>
                
                <?php
				 echo"<td class='f1_label'>Total:&nbsp $total </td>";
				 ?>
            </tr>
			
        </table>
            </center>
    </form> 
</div>
<center>
   <a href="print.php"><input type="button" name="submit"  value="print" style="left: 15px; top: 0px;"/></a>
</center>
       <h1><center>Thank you For buying...!!<br>visit again..</center></h1>
    </body>
</html>
