<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>computer details form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
    #comdetails_form {
    position: absolute;
    top: 20%;
    left: 30%;
    right: 30%;
    bottom: 20%;
    font-size: 18px;
}

#f1 {
    background-color: #ccc;
    border-radius: 5px;
    border-style: solid;
    border-width: 1px;
    padding: 10px;
    height: 140px;
    width: 300px;
    margin-left: 200px;
    margin-top: 150px
 
  
  
}
.f1_label {
   
   
}
.body{
    background-color:#d9f2e6;
}
        </style>
    </head>
        
    
    
   <body>
       

        
       <h1>ONLINE COMPUTER SHOPPING</h1>
  <link rel="stylesheet" type="text/css" href="home.css">
  <body background="p9.jpg">

    

       <div id="comdetails_form">
           <form name="f1" method="post" action="comp_up.php" id="f1">
        <table>
            <caption><b>Enter computer id to be updated</b></caption>
            <tr>
                <td class="f1_label">Computer id :</td>
                <td><input type="text" name="id" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Quantity :</td>
                <td><input type="text" name="quantity" value="" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Price :</td>
                <td><input type="text" name="price" value="" /> </td>
            </tr>
            
            <tr>
                <td>
                    <input type="submit" name="Submit" value="update" style="font-size:18px; " /></td>
                   <td> <a href="comdisp.php"><input type="button" name="disp" value="Disp" style="font-size:18px;"  /></a>

                </td>
                    
            </tr>
            
             
        </table>
    </form> 
</div>
    </body>
</html>


