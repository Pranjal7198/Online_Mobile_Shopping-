

<?php  
    include "database.php";
?>

<?php
   
$u=$_POST["id"];
$u1=$_POST["n"];
$i=$_POST["c"];
$e=$_POST["m"];
$un=$_POST["color"];
$p=$_POST["q"];
$a=$_POST["p"];
   
	
	
	$sql = "INSERT INTO laptop VALUES ('$u', '$u1', '$i', '$e', '$un', '$p', '$a')";
    
	$result = $conn->query($sql);
	      if($result===TRUE)
		  {
			  echo "<script type='text/javascript'>alert('Thank you');</script>";
		      echo "<script>window.location='amanger.php';</script>";
		  }
		  else
		  { echo "<script type='text/javascript'>alert('Not inserted');</script>";
		     echo "<script>window.location='amanger.php';</script>";
		  }
	$conn->close();
		  ?>





