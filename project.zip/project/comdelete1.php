<?php
include"database.php"
 ?>
 <?php
$i= $_POST['id']; 	


$sql="DELETE FROM `laptop` WHERE lap_id='$i'";
$result = $conn->query($sql);
 if($result===TRUE)
	{
	  echo "<script type='text/javascript'>alert('Delete');</script>";
		echo "<script>window.location='amanger.php';</script>";
	}
	else
	{
		$message="Not DELETE!";
		echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script>window.location='login.php';</script>";
		echo"<script>close()</script>";
	}
?>