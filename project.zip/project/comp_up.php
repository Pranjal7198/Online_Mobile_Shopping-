 <?php
 include"database.php";
?>
		<?php
		 $cid=$_POST['id'];
        $m=$_POST['quantity'];
        $d=$_POST['price'];
		$sql="update laptop set quantity='$m',price='$d' where lap_id='$cid' ";
$result = $conn->query($sql);
 if($result===TRUE)
	{
	  echo "<script type='text/javascript'>alert('Update Succesful!!');</script>";
		echo "<script>window.location='amanger.php';</script>";
	}
	else
	{
		$message="Not Updated!";
		echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script>window.location='login.php';</script>";
		echo"<script>close()</script>";
	}
		  ?>