<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            .div2{
                margin-top: 0px;
            }
        </style>
    </head>
    <a href="detail.html"><input type="button" name="display"  value="back" style="left: 15px; top: 0px;"/></a>

   
    <h1><b>Booking details</b></h1>
  <link rel="stylesheet" type="text/css" href="home.css">
<body background="p9.jpg">
     </div>
     
    

    


<?php



echo"<center>";
echo"<table border=2 bgcolor=#f2f2f2>"."<tr>";
echo"<th>"."computer_id"."</th>";
echo"<th>"." Name"."</th>";
echo"<th>"."Company"."</th>";
echo"<th>"."Model"."</th>";
echo"<th>"."color"."</th>";
echo"<th>"."quantity"."</th>";
echo"<th>"."Price"."</th></tr>";

           $result1=$coll1->find();
        foreach($result1 as $doc)
        {
      echo"<tr><td>".$doc['computer_id']."</td>"."<td>".$doc['quantity']."</td>"."<td>".$doc['price']."</td>"."</tr></>";

        }

echo"</table>";
echo"</center>";

?>


        

   
   



    
</body>
</html>
