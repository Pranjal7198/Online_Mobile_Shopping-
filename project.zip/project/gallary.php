<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>registration form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body background="o.jpg">
        <a href="sp1.php">
            <img src="1.jpg" alt="" style="width:330px;height:322px;">
        </a>
        <a href="sp2.php">
            <img src="10.jpg" alt="" style="width:330px;height:322px;">
        </a>
        <a href="sp3.php">
            <img src="11.jpg" alt="" style="width:330px;height:322px;">
        </a>
        <a href="sp4.php">
            <img src="9.jpg" alt="" style="width:330px;height:322px;">
        </a>
        <a href="sp5.php">
            <img src="2.jpg" alt="" style="width:330px;height:322px;">
        </a>
         <a href="sp6.php">
            <img src="3.png" alt="" style="width:330px;height:322px;">
        </a>
         <a href="sp7.php">
            <img src="7.jpg" alt="" style="width:330px;height:322px;">
        </a>
         <a href="sp8.php">
            <img src="8.jpg" alt="" style="width:330px;height:322px;">
        </a>
    </body>
    </body>

<?php
?>
</html>