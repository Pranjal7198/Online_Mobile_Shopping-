<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
         <style>
    #comdetails_form {
    position: absolute;
    margin:10px 100px 80px 180px;
    font-size: 18px;
}

#f1 {
    background-color: #ccc;
    border-radius: 5px;
    border-style: solid;
    border-width: 1px;
    padding: 10px;
    height: 100px;
    width: 300px;
    margin-left: 300px;
    margin-top: 270px
 
  
  
}
.div2{
    margin-top:50px;
}
.f1_label {
   
   
}
.body{
    background-color:#d9f2e6;
}
        </style>

    </head>
<body style="background:lightblue;">

<div id="comdetails_form">
    <form name="f1" method="post" action="buy.php" id="f1">
        <table>
            <caption><b>Enter quantity to be buy</b></caption>
            <tr>
                <td class="f1_label">Computer id :</td>
                <td><input type name="p" value="<?php echo $_GET['id']; ?>" /> </td>
            </tr>
            <tr>
                <td class="f1_label">Quantity :</td>
                <td><input type="number" name="quan" value="" /> </td>
            </tr>
            
            
            <tr>
                <td>
                    <a style="text-decoration:none;" href="bill.php"><input type="submit" name="Submit" value="submit" style="font-size:18px; " /></td>
                   <td> <a style="text-decoration:none;" href="index.php"><input type="button" name="display" value="back" style="font-size:18px;"  /></a>

                </td>
                    
            </tr>
            
             
        </table>
    </form> 
</div>
</body>
</html>