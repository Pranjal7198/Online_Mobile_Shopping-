

    <html>
    <head>
        <title>specification</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            .div1
            {
                font-size:20px;
                margin-left:500px;
                margin-top: 0px;
            }
            .img
            {
               height: 600px;
               width: 450px;
               float:left;
                
            }
        </style>
    </head>
    <body background="a1.jpg">
        <div class="img">
        <img src="1.jpg" alt="" style="width:400px;height:400px;">
        </div>
        <div class="div1">
        <ul>
        <b>Features</b><br>
        <li>computer id:100</li>
           <li>NTEL CORE 2 DUO 3 GHZ</li>
           <li>4GB</li>
<li>500GB</li>
<li>Dell 19 INCH LED</li>
<li>price:25000RS</li>
        </ul>
        </div>
<a href="p.php?id=100"><input type="button" name="display"  value="Buy" ></a>
    </body>
    </html>
