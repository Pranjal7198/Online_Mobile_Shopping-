<?php
	// ob_start();
	session_start();

	include "database.php";
	if(isset($_POST)  && !empty($_POST['u']) && !empty($_POST['p']))
	{
	$username=$_POST['u'];
	$password=$_POST['p'];
	
	$q="select * from `user` where  `username`='".$username."' and  `pass`='".$password."'";
	$res=$conn->query($q);
	if(mysqli_num_rows($res)>0)
	{
	  
		echo "<script>window.location='detail.html';</script>";
	}
	else
	{
		$message="Incorrect username/password found!";
		echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script>window.location='Ulogin.php';</script>";
		echo"<script>close()</script>";
	}
	}

?>
